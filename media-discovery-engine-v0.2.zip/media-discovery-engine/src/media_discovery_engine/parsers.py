from __future__ import annotations

import base64
import hashlib
import re
from dataclasses import asdict, dataclass
from pathlib import PurePosixPath
from typing import Any
from urllib.parse import parse_qs, urlsplit


@dataclass(slots=True)
class ParsedReference:
    protocol: str
    reference: str
    metadata: dict[str, Any]


class ParseError(ValueError):
    """Raised when an input does not match a supported syntax."""


def _parse_http_url(value: str) -> ParsedReference:
    parts = urlsplit(value)
    if parts.scheme.lower() not in {"http", "https"}:
        raise ParseError("URL precisa usar HTTP ou HTTPS")
    if not parts.hostname:
        raise ParseError("URL sem hostname")
    if any(ord(ch) < 32 for ch in value):
        raise ParseError("URL contém caracteres de controle")

    path = parts.path.lower()
    if path.endswith(".m3u8"):
        protocol = "M3U8"
    elif path.endswith(".torrent"):
        protocol = "TORRENT_URL"
    else:
        protocol = "HTTP"

    return ParsedReference(
        protocol=protocol,
        reference=value,
        metadata={"host": parts.hostname, "path": parts.path},
    )


def parse_magnet(value: str) -> ParsedReference:
    parts = urlsplit(value.strip())
    if parts.scheme.lower() != "magnet":
        raise ParseError("Esquema magnet inválido")

    params = parse_qs(parts.query)
    xt_values = params.get("xt", [])
    match = next(
        (
            re.fullmatch(
                r"urn:btih:(?P<hash>[A-Fa-f0-9]{40}|[A-Z2-7a-z2-7]{32})",
                item,
            )
            for item in xt_values
        ),
        None,
    )
    if not match:
        raise ParseError("Magnet URI sem xt=urn:btih válido")

    info_hash = match.group("hash").lower()
    return ParsedReference(
        protocol="MAGNET",
        reference=value.strip(),
        metadata={
            "info_hash": info_hash,
            "display_name": params.get("dn", [None])[0],
            "trackers_count": len(params.get("tr", [])),
        },
    )


def _parse_extinf(line: str) -> dict[str, Any]:
    # Captura atributos comuns sem depender de uma ordem específica.
    attrs: dict[str, str] = {}
    for match in re.finditer(r'([\w-]+)="([^"]*)"', line):
        attrs[match.group(1).lower()] = match.group(2)

    title = line.split(",", 1)[1].strip() if "," in line else None
    return {
        "title": title,
        "tvg_id": attrs.get("tvg-id"),
        "tvg_name": attrs.get("tvg-name"),
        "logo": attrs.get("tvg-logo"),
        "group": attrs.get("group-title"),
        "raw_extinf": line[:2000],
    }


def parse_m3u(content: str, *, protocol: str = "M3U") -> list[ParsedReference]:
    lines = [line.strip() for line in content.replace("\r\n", "\n").splitlines()]
    if not lines or not lines[0].startswith("#EXTM3U"):
        raise ParseError("Lista sem cabeçalho #EXTM3U")

    records: list[ParsedReference] = []
    pending: dict[str, Any] = {}
    for line in lines[1:]:
        if not line:
            continue
        if line.startswith("#EXTINF:"):
            pending = _parse_extinf(line)
        elif line.startswith("#"):
            # Diretivas M3U/M3U8 não são referências de mídia.
            continue
        else:
            ref = parse_reference(line)
            metadata = {**pending, "playlist_protocol": protocol}
            records.append(
                ParsedReference(
                    protocol=ref.protocol,
                    reference=ref.reference,
                    metadata=metadata,
                )
            )
            pending = {}

    return records


def parse_m3u8_manifest(content: str) -> list[ParsedReference]:
    if "#EXTM3U" not in content[:100]:
        raise ParseError("Manifesto HLS sem #EXTM3U")

    records: list[ParsedReference] = []
    pending: dict[str, Any] = {}
    for raw in content.replace("\r\n", "\n").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXTINF:"):
            pending = _parse_extinf(line)
        elif line.startswith("#EXT-X-STREAM-INF:"):
            pending = {"variant": line.split(":", 1)[1][:1000]}
        elif line.startswith("#"):
            continue
        else:
            ref = parse_reference(line)
            records.append(
                ParsedReference(
                    protocol=ref.protocol,
                    reference=ref.reference,
                    metadata={**pending, "manifest_type": "HLS"},
                )
            )
            pending = {}
    return records


def parse_reference(value: str) -> ParsedReference:
    value = value.strip()
    if not value:
        raise ParseError("Referência vazia")
    if value.lower().startswith("magnet:"):
        return parse_magnet(value)
    if value.lower().startswith(("http://", "https://")):
        return _parse_http_url(value)
    raise ParseError("Formato não reconhecido; esperado HTTP(S) ou Magnet URI")


def _bdecode(data: bytes, pos: int = 0, depth: int = 0):
    """Small bounded bencode decoder returning (value, end_position)."""
    if depth > 64 or pos >= len(data):
        raise ParseError("Torrent bencoded inválido ou profundo demais")

    token = data[pos:pos + 1]
    if token == b"i":
        end = data.find(b"e", pos)
        if end < 0:
            raise ParseError("Inteiro bencode sem terminador")
        try:
            return int(data[pos + 1:end]), end + 1
        except ValueError as exc:
            raise ParseError("Inteiro bencode inválido") from exc

    if token == b"l":
        result = []
        pos += 1
        while pos < len(data) and data[pos:pos + 1] != b"e":
            value, pos = _bdecode(data, pos, depth + 1)
            result.append(value)
            if len(result) > 100_000:
                raise ParseError("Lista torrent excede limite")
        if pos >= len(data):
            raise ParseError("Lista bencode sem terminador")
        return result, pos + 1

    if token == b"d":
        result = {}
        pos += 1
        count = 0
        while pos < len(data) and data[pos:pos + 1] != b"e":
            key, pos = _bdecode(data, pos, depth + 1)
            if not isinstance(key, bytes):
                raise ParseError("Chave de dicionário bencode inválida")
            value, pos = _bdecode(data, pos, depth + 1)
            result[key] = value
            count += 1
            if count > 100_000:
                raise ParseError("Dicionário torrent excede limite")
        if pos >= len(data):
            raise ParseError("Dicionário bencode sem terminador")
        return result, pos + 1

    if token.isdigit():
        colon = data.find(b":", pos)
        if colon < 0:
            raise ParseError("String bencode sem tamanho")
        try:
            size = int(data[pos:colon])
        except ValueError as exc:
            raise ParseError("Tamanho bencode inválido") from exc
        if size < 0 or size > 64 * 1024 * 1024:
            raise ParseError("String torrent excede limite")
        start, end = colon + 1, colon + 1 + size
        if end > len(data):
            raise ParseError("String bencode truncada")
        return data[start:end], end

    raise ParseError("Token bencode desconhecido")


def parse_torrent_bytes(data: bytes, filename: str = "upload.torrent") -> ParsedReference:
    if not data or len(data) > 64 * 1024 * 1024:
        raise ParseError("Arquivo torrent vazio ou maior que 64 MiB")

    decoded, end = _bdecode(data)
    if end != len(data) or not isinstance(decoded, dict):
        raise ParseError("Estrutura torrent inválida")

    info = decoded.get(b"info")
    if not isinstance(info, dict):
        raise ParseError("Torrent sem dicionário info")

    # O infohash é calculado sobre a representação bencoded original do campo info.
    info_start = data.find(b"d")
    if info_start < 0:
        raise ParseError("Dicionário info não encontrado")
    # Localiza o campo info sem reserializar os dados.
    cursor = 1
    info_raw = None
    while cursor < len(data) and data[cursor:cursor + 1] != b"e":
        key, key_end = _bdecode(data, cursor)
        value_start = key_end
        value, value_end = _bdecode(data, value_start)
        if key == b"info":
            info_raw = data[value_start:value_end]
            break
        cursor = value_end

    if info_raw is None:
        raise ParseError("Campo info não encontrado")

    name = info.get(b"name.utf-8", info.get(b"name", b""))
    if isinstance(name, bytes):
        name = name.decode("utf-8", errors="replace")

    files = info.get(b"files")
    if isinstance(files, list):
        file_count = len(files)
        total_bytes = sum(
            item.get(b"length", 0)
            for item in files
            if isinstance(item, dict) and isinstance(item.get(b"length", 0), int)
        )
    else:
        file_count = 1
        total_bytes = info.get(b"length", 0)

    info_hash = hashlib.sha1(info_raw).hexdigest()
    announce = decoded.get(b"announce")
    if isinstance(announce, bytes):
        announce = announce.decode("utf-8", errors="replace")

    return ParsedReference(
        protocol="TORRENT",
        reference=f"torrent:btih:{info_hash}",
        metadata={
            "info_hash": info_hash,
            "name": str(name),
            "file_count": file_count,
            "total_bytes": total_bytes if isinstance(total_bytes, int) else None,
            "announce": announce,
            "filename": PurePosixPath(filename).name,
        },
    )


def parsed_to_dict(record: ParsedReference) -> dict[str, Any]:
    return asdict(record)
