from __future__ import annotations
import argparse, time
from .service import IngestionService
from .storage import Storage

def run(poll_seconds: float = 1.0, once: bool = False):
    storage = Storage()
    service = IngestionService(storage)
    while True:
        job = storage.claim_job()
        if job is None:
            if once: return
            time.sleep(poll_seconds)
            continue
        try:
            result = service.ingest_batch(job["payload"])
            storage.finish_job(job["id"], result=result)
        except Exception as exc:
            storage.finish_job(job["id"], error=str(exc))
        if once: return

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--poll-seconds", type=float, default=1.0)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    run(args.poll_seconds, args.once)

if __name__ == "__main__": main()
