# Changelog

## 0.2.0
- Added FastAPI endpoints for health, statistics, search, batch ingestion, sources and jobs.
- Added SQLAlchemy storage with SQLite development mode and PostgreSQL production configuration.
- Added persistent ingestion queue and standalone worker.
- Added basic administrative dashboard.
- Added API-key protection when `MDE_API_KEY` is configured.
- Added Docker Compose, GitHub Actions and API/worker integration tests.
