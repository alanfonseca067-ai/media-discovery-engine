from __future__ import annotations
import os
from typing import Any
from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from .service import IngestionService
from .storage import Storage

app = FastAPI(title="Media Discovery Engine API", version="0.2.0",
              description="Indexador de metadados; não baixa nem reproduz mídia.")
storage = Storage()
service = IngestionService(storage)
API_KEY = os.getenv("MDE_API_KEY", "")

class BatchRequest(BaseModel):
    items: list[dict[str, Any]] = Field(min_length=1, max_length=1000)
class JobRequest(BaseModel):
    items: list[dict[str, Any]] = Field(min_length=1, max_length=10000)

class SourceRequest(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    source_type: str = Field(min_length=2, max_length=40)
    reference: str = Field(min_length=1, max_length=4000)
    notes: str | None = Field(default=None, max_length=2000)

def authorize(x_api_key: str | None):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="API key inválida ou ausente")

@app.get("/health")
def health():
    return {"status": "ok", "service": "mde-api", "version": "0.2.0"}

@app.get("/v1/stats")
def stats(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return storage.stats()

@app.get("/v1/references")
def references(q: str = "", protocol: str | None = None,
               limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
               x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {"items": storage.search(q, protocol, limit, offset), "limit": limit, "offset": offset}

@app.post("/v1/ingest")
def ingest(request: BatchRequest, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return service.ingest_batch(request.items)

@app.get("/v1/sources")
def list_sources(x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {"items": storage.list_sources()}

@app.post("/v1/sources", status_code=201)
def add_source(request: SourceRequest, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    source_id = storage.add_source(request.name, request.source_type, request.reference, request.notes)
    return {"id": source_id, "status": "registered"}

@app.post("/v1/jobs", status_code=202)
def create_job(request: JobRequest, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    return {"job_id": storage.enqueue(request.items), "status": "queued"}

@app.get("/v1/jobs/{job_id}")
def job_status(job_id: int, x_api_key: str | None = Header(default=None)):
    authorize(x_api_key)
    job = storage.get_job(job_id)
    if not job: raise HTTPException(status_code=404, detail="Tarefa não encontrada")
    return job

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return DASHBOARD

DASHBOARD = """<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MDE Admin</title><style>
body{font:15px system-ui;background:#101522;color:#e8edf7;margin:0;padding:28px}main{max-width:1000px;margin:auto}
.card{background:#1b2638;border:1px solid #33445e;border-radius:12px;padding:18px;margin:14px 0}
input,button,select{padding:10px;border-radius:8px;border:1px solid #52627b;background:#111b2b;color:#fff}
button{cursor:pointer;background:#2563eb;border:0}pre{white-space:pre-wrap;overflow-wrap:anywhere}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}.metric{font-size:25px;font-weight:700}
</style></head><body><main><h1>Media Discovery Engine</h1><p>Painel administrativo · indexação de metadados</p>
<section class="card"><label>API key (se configurada): <input id="key" type="password" placeholder="MDE_API_KEY"></label>
<button onclick="refresh()">Atualizar painel</button></section><section class="grid" id="metrics"></section>
<section class="card"><h2>Pesquisar referências</h2><input id="q" placeholder="URL ou trecho da referência">
<select id="protocol"><option value="">Todos</option><option>HTTP</option><option>M3U8</option><option>MAGNET</option><option>TORRENT</option><option>TORRENT_URL</option></select>
<button onclick="searchRefs()">Pesquisar</button><pre id="results"></pre></section>
<section class="card"><h2>Importação rápida</h2><p>Envie JSON com a propriedade <code>items</code>.</p>
<textarea id="payload" rows="5" style="width:98%;background:#111b2b;color:white">{"items":[{"value":"https://example.org/demo.m3u8"}]}</textarea>
<br><button onclick="ingest()">Importar</button><pre id="importResult"></pre></section></main>
<script>
function headers(){const k=document.getElementById('key').value;return k?{'X-API-Key':k}:{}}
async function api(path,opts={}){return fetch(path,{...opts,headers:{...headers(),...(opts.headers||{})}})}
async function refresh(){let r=await api('/v1/stats');let d=await r.json();document.getElementById('metrics').innerHTML=
`<div class="card"><div class="metric">${d.total_records}</div>Referências</div>`+
Object.entries(d.by_protocol||{}).map(([k,v])=>`<div class="card"><div class="metric">${v}</div>${k}</div>`).join('')}
async function searchRefs(){let q=encodeURIComponent(document.getElementById('q').value),p=encodeURIComponent(document.getElementById('protocol').value);
let r=await api(`/v1/references?q=${q}&protocol=${p}`);document.getElementById('results').textContent=JSON.stringify(await r.json(),null,2)}
async function ingest(){try{let body=JSON.parse(document.getElementById('payload').value);let r=await api('/v1/ingest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
document.getElementById('importResult').textContent=JSON.stringify(await r.json(),null,2);refresh()}catch(e){document.getElementById('importResult').textContent=String(e)}}
refresh();
</script></body></html>"""
