from fastapi.testclient import TestClient
from media_discovery_engine import api
from media_discovery_engine.storage import Storage
from media_discovery_engine.service import IngestionService
from media_discovery_engine.worker import run

def setup_api(tmp_path, monkeypatch):
    store = Storage(f"sqlite:///{tmp_path / 'api.sqlite3'}")
    monkeypatch.setattr(api, "storage", store)
    monkeypatch.setattr(api, "service", IngestionService(store))
    monkeypatch.setattr(api, "API_KEY", "test-secret")
    return store, TestClient(api.app)

def test_api_health_and_auth(tmp_path, monkeypatch):
    store, client = setup_api(tmp_path, monkeypatch)
    assert client.get("/health").json()["status"] == "ok"
    assert client.get("/v1/stats").status_code == 401
    assert client.get("/v1/stats", headers={"X-API-Key":"test-secret"}).status_code == 200

def test_api_ingest_search_and_stats(tmp_path, monkeypatch):
    store, client = setup_api(tmp_path, monkeypatch)
    headers={"X-API-Key":"test-secret"}
    response=client.post("/v1/ingest", headers=headers, json={"items":[
        {"value":"https://example.org/movie.mp4"},
        {"value":"magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567"}
    ]})
    assert response.status_code == 200
    assert response.json()["inserted"] == 2
    found=client.get("/v1/references?protocol=HTTP",headers=headers).json()
    assert len(found["items"]) == 1
    assert client.get("/v1/stats",headers=headers).json()["total_records"] == 2

def test_persistent_job_worker_lifecycle(tmp_path, monkeypatch):
    db_url=f"sqlite:///{tmp_path / 'jobs.sqlite3'}"
    monkeypatch.setenv("DATABASE_URL", db_url)
    store=Storage(db_url)
    job_id=store.enqueue([{"value":"https://example.org/queued.m3u8"}])
    run(once=True)
    job=store.get_job(job_id)
    assert job["status"] == "completed"
    assert job["result"]["inserted"] == 1


def test_source_registry_api(tmp_path, monkeypatch):
    store, client = setup_api(tmp_path, monkeypatch)
    headers={"X-API-Key":"test-secret"}
    created=client.post("/v1/sources",headers=headers,json={
        "name":"Public sample feed","source_type":"M3U","reference":"https://example.org/list.m3u",
        "notes":"Reference only; no automatic fetching"
    })
    assert created.status_code == 201
    listed=client.get("/v1/sources",headers=headers).json()["items"]
    assert listed[0]["name"] == "Public sample feed"
