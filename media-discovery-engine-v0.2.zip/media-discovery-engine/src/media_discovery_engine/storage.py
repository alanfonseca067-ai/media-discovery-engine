from __future__ import annotations
import hashlib, os
from datetime import datetime, timezone
from typing import Any
from sqlalchemy import (Column, DateTime, Integer, JSON, MetaData, String, Table, Text,
                        create_engine, select, insert, update, func)
from sqlalchemy.exc import IntegrityError
from sqlalchemy.engine import Engine

metadata = MetaData()
records = Table("media_references", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("protocol", String(32), nullable=False, index=True),
    Column("reference", Text, nullable=False),
    Column("metadata_json", JSON, nullable=False),
    Column("fingerprint", String(64), nullable=False, unique=True, index=True),
    Column("created_at", DateTime(timezone=True), nullable=False))
jobs = Table("ingestion_jobs", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("status", String(20), nullable=False, index=True),
    Column("payload", JSON, nullable=False), Column("result", JSON),
    Column("error", Text), Column("created_at", DateTime(timezone=True), nullable=False),
    Column("updated_at", DateTime(timezone=True), nullable=False))
sources = Table("source_registry", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("name", String(200), nullable=False),
    Column("source_type", String(40), nullable=False),
    Column("reference", Text, nullable=False),
    Column("notes", Text),
    Column("enabled", Integer, nullable=False, default=1),
    Column("created_at", DateTime(timezone=True), nullable=False))

class Storage:
    def __init__(self, database_url: str | None = None):
        url = database_url or os.getenv("DATABASE_URL", "sqlite:///./data/mde.sqlite3")
        if url.startswith("sqlite"):
            from pathlib import Path
            Path("data").mkdir(exist_ok=True)
            self.engine: Engine = create_engine(url, connect_args={"check_same_thread": False})
        else:
            self.engine = create_engine(url, pool_pre_ping=True, pool_size=5, max_overflow=10)
        metadata.create_all(self.engine)

    @staticmethod
    def fingerprint(protocol: str, reference: str) -> str:
        return hashlib.sha256(f"{protocol}:{reference}".encode()).hexdigest()

    def save(self, protocol: str, reference: str, metadata_json: dict[str, Any]) -> bool:
        fp = self.fingerprint(protocol, reference)
        try:
            with self.engine.begin() as conn:
                exists = conn.execute(select(records.c.id).where(records.c.fingerprint == fp)).first()
                if exists:
                    return False
                conn.execute(insert(records).values(protocol=protocol, reference=reference,
                    metadata_json=metadata_json, fingerprint=fp, created_at=datetime.now(timezone.utc)))
            return True
        except IntegrityError:
            # Another worker may have inserted the same fingerprint concurrently.
            return False

    def search(self, query="", protocol=None, limit=50, offset=0):
        stmt = select(records)
        if query: stmt = stmt.where(records.c.reference.ilike(f"%{query}%"))
        if protocol: stmt = stmt.where(records.c.protocol == protocol.upper())
        stmt = stmt.order_by(records.c.id.desc()).limit(limit).offset(offset)
        with self.engine.connect() as conn:
            return [dict(row._mapping) for row in conn.execute(stmt).all()]

    def stats(self):
        with self.engine.connect() as conn:
            total = conn.execute(select(func.count()).select_from(records)).scalar_one()
            grouped = conn.execute(select(records.c.protocol, func.count()).group_by(records.c.protocol)).all()
            job_rows = conn.execute(select(jobs.c.status, func.count()).group_by(jobs.c.status)).all()
        return {"total_records": total, "by_protocol": {k:v for k,v in grouped},
                "jobs": {k:v for k,v in job_rows}}

    def enqueue(self, payload):
        now = datetime.now(timezone.utc)
        with self.engine.begin() as conn:
            result = conn.execute(insert(jobs).values(status="queued", payload=payload,
                result=None, error=None, created_at=now, updated_at=now))
            return int(result.inserted_primary_key[0])

    def get_job(self, job_id):
        with self.engine.connect() as conn:
            row = conn.execute(select(jobs).where(jobs.c.id == job_id)).first()
        return dict(row._mapping) if row else None

    def claim_job(self):
        with self.engine.begin() as conn:
            row = conn.execute(select(jobs).where(jobs.c.status == "queued")
                               .order_by(jobs.c.id).limit(1).with_for_update(skip_locked=True)).first()
            if not row: return None
            conn.execute(update(jobs).where(jobs.c.id == row.id, jobs.c.status == "queued")
                         .values(status="running", updated_at=datetime.now(timezone.utc)))
            return dict(row._mapping)

    def finish_job(self, job_id, result=None, error=None):
        with self.engine.begin() as conn:
            conn.execute(update(jobs).where(jobs.c.id == job_id).values(
                status="failed" if error else "completed", result=result, error=error,
                updated_at=datetime.now(timezone.utc)))

    def add_source(self, name: str, source_type: str, reference: str, notes: str | None = None):
        with self.engine.begin() as conn:
            result = conn.execute(insert(sources).values(
                name=name, source_type=source_type, reference=reference, notes=notes,
                enabled=1, created_at=datetime.now(timezone.utc)))
            return int(result.inserted_primary_key[0])

    def list_sources(self):
        with self.engine.connect() as conn:
            return [dict(row._mapping) for row in conn.execute(
                select(sources).order_by(sources.c.id.desc())).all()]
