import hashlib

import pytest

from media_discovery_engine.parsers import (
    ParseError,
    parse_m3u,
    parse_m3u8_manifest,
    parse_magnet,
    parse_reference,
    parse_torrent_bytes,
)


def test_http_and_hls_url_detection():
    assert parse_reference("https://media.example/video.mp4").protocol == "HTTP"
    assert parse_reference("https://media.example/live/index.m3u8").protocol == "M3U8"


def test_magnet_validates_infohash():
    record = parse_magnet(
        "magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567&dn=Example"
    )
    assert record.metadata["info_hash"] == "0123456789abcdef0123456789abcdef01234567"
    assert record.metadata["display_name"] == "Example"


def test_invalid_magnet_rejected():
    with pytest.raises(ParseError):
        parse_magnet("magnet:?dn=missing-hash")


def test_m3u_extracts_entries_and_metadata():
    content = """#EXTM3U
#EXTINF:-1 tvg-id="news" group-title="News",Example News
https://example.org/live.m3u8
"""
    records = parse_m3u(content)
    assert len(records) == 1
    assert records[0].metadata["title"] == "Example News"
    assert records[0].metadata["group"] == "News"
    assert records[0].protocol == "M3U8"


def test_m3u8_manifest_extracts_segments():
    content = """#EXTM3U
#EXT-X-TARGETDURATION:10
#EXTINF:10,
https://cdn.example/segment001.ts
#EXT-X-ENDLIST
"""
    records = parse_m3u8_manifest(content)
    assert len(records) == 1
    assert records[0].metadata["manifest_type"] == "HLS"


def test_torrent_parser_extracts_infohash_and_name():
    # bencoded metainfo with info={length: 123, name: "demo", piece length: 16384, pieces: 20 bytes}
    info = b"d6:lengthi123e4:name4:demo12:piece lengthi16384e6:pieces20:12345678901234567890e"
    payload = b"d4:info" + info + b"e"
    record = parse_torrent_bytes(payload, "demo.torrent")
    assert record.protocol == "TORRENT"
    assert record.metadata["name"] == "demo"
    assert record.metadata["total_bytes"] == 123
    assert record.metadata["info_hash"] == hashlib.sha1(info).hexdigest()


def test_invalid_http_rejected():
    with pytest.raises(ParseError):
        parse_reference("https:///missing-host")
