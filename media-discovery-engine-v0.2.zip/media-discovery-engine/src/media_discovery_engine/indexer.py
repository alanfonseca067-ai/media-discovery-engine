from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .parsers import (
    ParseError,
    ParsedReference,
    parse_m3u,
    parse_m3u8_manifest,
    parse_reference,
    parse_torrent_bytes,
)


class Indexer:
    def __init__(self, database_path: str = "data/mde.sqlite3"):
        self.database_path = database_path
        Path(database_path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self):
        connection = sqlite3.connect(self.database_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self):
        with self._connect() as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS media_references (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    protocol TEXT NOT NULL,
                    reference TEXT NOT NULL,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    fingerprint TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            """)
            db.execute("""
                CREATE INDEX IF NOT EXISTS idx_media_protocol
                ON media_references(protocol)
            """)

    @staticmethod
    def _fingerprint(record: ParsedReference) -> str:
        raw = f"{record.protocol}:{record.reference}".encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def _insert(self, db, record: ParsedReference) -> bool:
        cursor = db.execute(
            """
            INSERT OR IGNORE INTO media_references
            (protocol, reference, metadata_json, fingerprint)
            VALUES (?, ?, ?, ?)
            """,
            (
                record.protocol,
                record.reference,
                json.dumps(record.metadata, ensure_ascii=False),
                self._fingerprint(record),
            ),
        )
        return cursor.rowcount == 1

    def ingest_record(self, item: dict[str, Any], db=None) -> tuple[int, int, int]:
        """Ingest one JSON-like record. Returns (inserted, rejected, duplicates)."""
        own_connection = db is None
        connection = db or self._connect()
        inserted = rejected = duplicates = 0

        try:
            kind = str(item.get("type", "")).lower()
            value = item.get("value")
            content = item.get("content")

            if kind in {"torrent", "application/x-bittorrent"}:
                raw = item.get("torrent_base64")
                if not isinstance(raw, str):
                    raise ParseError("Registro torrent requer torrent_base64")
                import base64
                record = parse_torrent_bytes(
                    base64.b64decode(raw, validate=True),
                    item.get("filename", "upload.torrent"),
                )
                added = self._insert(connection, record)
                inserted += int(added)
                duplicates += int(not added)

            elif kind in {"m3u", "m3u8"} or (
                isinstance(content, str) and content.lstrip().startswith("#EXTM3U")
            ):
                if not isinstance(content, str):
                    raise ParseError("Lista requer o campo content")
                records = (
                    parse_m3u8_manifest(content)
                    if kind == "m3u8"
                    else parse_m3u(content)
                )
                for record in records:
                    added = self._insert(connection, record)
                    inserted += int(added)
                    duplicates += int(not added)

            elif isinstance(value, str):
                record = parse_reference(value)
                if kind == "m3u8":
                    record.protocol = "M3U8"
                added = self._insert(connection, record)
                inserted += int(added)
                duplicates += int(not added)

            else:
                raise ParseError("Registro precisa conter value, content ou torrent_base64")

        except (ParseError, ValueError, TypeError):
            rejected += 1
        finally:
            if own_connection:
                connection.commit()
                connection.close()

        return inserted, rejected, duplicates

    def ingest_batch(self, items: Iterable[dict[str, Any]]) -> dict[str, int]:
        inserted = rejected = duplicates = received = 0
        with self._connect() as db:
            for item in items:
                received += 1
                added, failed, repeated = self.ingest_record(item, db=db)
                inserted += added
                rejected += failed
                duplicates += repeated
        return {
            "received": received,
            "inserted": inserted,
            "rejected": rejected,
            "duplicates": duplicates,
        }

    def list_records(self, limit: int = 100, protocol: str | None = None):
        limit = max(1, min(limit, 1000))
        with self._connect() as db:
            if protocol:
                rows = db.execute(
                    "SELECT * FROM media_references WHERE protocol=? ORDER BY id DESC LIMIT ?",
                    (protocol.upper(), limit),
                ).fetchall()
            else:
                rows = db.execute(
                    "SELECT * FROM media_references ORDER BY id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [dict(row) for row in rows]

    def count(self) -> int:
        with self._connect() as db:
            return int(db.execute("SELECT COUNT(*) FROM media_references").fetchone()[0])
