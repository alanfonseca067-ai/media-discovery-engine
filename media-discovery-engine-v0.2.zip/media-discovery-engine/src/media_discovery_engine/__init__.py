"""Media Discovery Engine: metadata-only protocol parser and indexer."""

__version__ = "0.1.0"
