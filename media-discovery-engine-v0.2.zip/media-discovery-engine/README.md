# Media Discovery Engine (MDE) v0.2

MDE é um serviço de **indexação de metadados** para referências fornecidas pelo operador. Reconhece URLs HTTP/HTTPS, Magnet URI, metainfo `.torrent`, listas M3U e manifestos HLS/M3U8.

## Limites de segurança e escopo
- Não realiza crawling indiscriminado, scraping de fóruns, consultas DHT, downloads P2P, downloads de vídeos nem reprodução de streams.
- Não abre nem testa URLs remotas. A disponibilidade e o direito de distribuição precisam ser verificados pelo operador antes de habilitar reprodução.
- O parser `.torrent` lê metadados do arquivo local fornecido; não inicia cliente BitTorrent.
- Importe somente referências e conteúdos que você tenha autorização para catalogar e distribuir.
- A API usa chave se `MDE_API_KEY` estiver configurada. Em produção, configure uma chave forte e coloque a API atrás de HTTPS.

## Recursos
- Parsers HTTP/HTTPS, Magnet, M3U, M3U8/HLS e `.torrent` local.
- Importação síncrona em lote (até 1.000 itens por requisição).
- Fila persistente no banco e worker separado para lotes grandes (até 10.000 itens por tarefa).
- PostgreSQL em produção ou SQLite para desenvolvimento.
- Busca por texto e protocolo, estatísticas, registro de fontes e painel administrativo básico.
- Deduplicação por fingerprint SHA-256.
- API FastAPI documentada automaticamente em `/docs`.

## Rodar localmente
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e ".[dev]"\n# Para PostgreSQL fora do Docker: pip install -e ".[postgres]"
export MDE_API_KEY="use-uma-chave-forte"
uvicorn media_discovery_engine.api:app --reload
```
Abra `http://127.0.0.1:8000/` para o painel e `http://127.0.0.1:8000/docs` para a documentação da API.

## Endpoints
- `GET /health` — saúde do serviço.
- `GET /v1/stats` — totais por protocolo.
- `GET /v1/references?q=&protocol=&limit=&offset=` — pesquisar referências.
- `POST /v1/ingest` — importação síncrona.
- `GET /v1/sources` e `POST /v1/sources` — registrar/listar referências de fontes (sem coleta automática).\n- `POST /v1/jobs` — enfileirar lote para o worker.
- `GET /v1/jobs/{id}` — consultar estado da tarefa.

Envie `X-API-Key: sua-chave` quando `MDE_API_KEY` estiver configurada.

Exemplo de importação:
```json
{
  "items": [
    {"value": "https://example.org/metadata-only-demo.m3u8"},
    {"value": "magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567"},
    {"type": "m3u", "content": "#EXTM3U\\n#EXTINF:-1,Demo\\nhttps://example.org/demo.m3u8\\n"}
  ]
}
```

Para `.torrent`, envie metainfo local em Base64:
```json
{"items":[{"type":"torrent","filename":"public-domain.torrent","torrent_base64":"BASE64_DO_ARQUIVO"}]}
```

## Worker e fila
Em outro terminal:
```bash
mde-worker
```
Ou execute uma única tarefa pendente:
```bash
mde-worker --once
```
A fila é persistida no banco. O worker usa `FOR UPDATE SKIP LOCKED` em bancos que suportam bloqueio de linha (como PostgreSQL), permitindo múltiplos workers; para produção, adicione também política de recuperação de jobs abandonados e monitoramento de filas.

## Docker Compose (PostgreSQL + API + worker)
```bash
cp .env.example .env
# Edite .env e substitua as duas senhas/chaves de exemplo.
docker compose up --build -d
```
API: `http://localhost:8000`; painel: `/`; documentação: `/docs`.
**Não exponha a porta pública sem HTTPS, chave forte e regras de firewall.**

## Testes
```bash
pytest -q
```
