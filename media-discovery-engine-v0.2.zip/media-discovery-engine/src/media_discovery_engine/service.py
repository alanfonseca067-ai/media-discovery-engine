from __future__ import annotations
import base64
from typing import Any
from .parsers import ParseError, parse_m3u, parse_m3u8_manifest, parse_reference, parse_torrent_bytes
from .storage import Storage

class IngestionService:
    def __init__(self, storage: Storage): self.storage = storage

    def ingest_item(self, item: dict[str, Any]):
        kind = str(item.get("type", "")).lower()
        if kind in {"torrent", "application/x-bittorrent"}:
            encoded = item.get("torrent_base64")
            if not isinstance(encoded, str): raise ParseError("torrent_base64 é obrigatório")
            try: raw = base64.b64decode(encoded, validate=True)
            except Exception as exc: raise ParseError("torrent_base64 inválido") from exc
            return [parse_torrent_bytes(raw, item.get("filename", "upload.torrent"))]
        if kind in {"m3u", "m3u8"}:
            content = item.get("content")
            if not isinstance(content, str): raise ParseError("content é obrigatório")
            return parse_m3u8_manifest(content) if kind == "m3u8" else parse_m3u(content)
        value = item.get("value")
        if not isinstance(value, str): raise ParseError("value deve conter uma referência textual")
        parsed = parse_reference(value)
        if kind == "m3u8": parsed.protocol = "M3U8"
        return [parsed]

    def ingest_batch(self, items: list[dict[str, Any]]):
        inserted = rejected = duplicates = parsed_count = 0
        errors = []
        for index, item in enumerate(items):
            try:
                parsed_records = self.ingest_item(item)
                parsed_count += len(parsed_records)
                for parsed in parsed_records:
                    if self.storage.save(parsed.protocol, parsed.reference, parsed.metadata): inserted += 1
                    else: duplicates += 1
            except (ParseError, ValueError, TypeError) as exc:
                rejected += 1
                if len(errors) < 50: errors.append({"item": index, "error": str(exc)})
        return {"received": len(items), "parsed_references": parsed_count, "inserted": inserted,
                "duplicates": duplicates, "rejected_items": rejected, "errors": errors}
