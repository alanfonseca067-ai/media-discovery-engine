import json

from media_discovery_engine.indexer import Indexer


def test_batch_import_deduplicates_and_persists(tmp_path):
    indexer = Indexer(str(tmp_path / "test.sqlite3"))
    batch = [
        {"value": "https://example.org/movie.mp4"},
        {"value": "https://example.org/movie.mp4"},
        {"value": "not-a-url"},
        {"value": "magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567"},
    ]
    result = indexer.ingest_batch(batch)
    assert result["inserted"] == 2
    assert result["rejected"] == 1
    assert indexer.count() == 2


def test_m3u_batch_import(tmp_path):
    indexer = Indexer(str(tmp_path / "test.sqlite3"))
    result = indexer.ingest_batch([{
        "type": "m3u",
        "content": "#EXTM3U\n#EXTINF:-1,Demo\nhttps://example.org/demo.mp4\n",
    }])
    assert result["inserted"] == 1
    row = indexer.list_records()[0]
    assert row["protocol"] == "HTTP"
    assert json.loads(row["metadata_json"])["title"] == "Demo"
