from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path

from .indexer import Indexer
from .parsers import ParseError, parse_torrent_bytes


def read_jsonl(path: Path, batch_size: int):
    batch = []
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                batch.append(json.loads(line))
            except json.JSONDecodeError as exc:
                print(json.dumps({
                    "line": line_number,
                    "error": f"JSON inválido: {exc.msg}",
                }, ensure_ascii=False))
                continue
            if len(batch) >= batch_size:
                yield batch
                batch = []
    if batch:
        yield batch


def main():
    parser = argparse.ArgumentParser(prog="mde")
    parser.add_argument("--db", default="data/mde.sqlite3")
    sub = parser.add_subparsers(dest="command", required=True)

    ingest = sub.add_parser("ingest", help="Importar registros JSONL em lote")
    ingest.add_argument("input", type=Path)
    ingest.add_argument("--batch-size", type=int, default=500)

    torrent = sub.add_parser("torrent", help="Indexar metadados de um .torrent local")
    torrent.add_argument("input", type=Path)

    sub.add_parser("stats", help="Mostrar total de registros")

    args = parser.parse_args()
    indexer = Indexer(args.db)

    if args.command == "ingest":
        if args.batch_size < 1 or args.batch_size > 10000:
            parser.error("--batch-size deve ficar entre 1 e 10000")
        totals = {"received": 0, "inserted": 0, "rejected": 0}
        for batch in read_jsonl(args.input, args.batch_size):
            result = indexer.ingest_batch(batch)
            for key in totals:
                totals[key] += result[key]
            print(json.dumps(result, ensure_ascii=False))
        print(json.dumps({"totals": totals}, ensure_ascii=False))

    elif args.command == "torrent":
        data = args.input.read_bytes()
        record = parse_torrent_bytes(data, args.input.name)
        result = indexer.ingest_batch([{
            "type": "torrent",
            "torrent_base64": base64.b64encode(data).decode("ascii"),
            "filename": args.input.name,
        }])
        print(json.dumps({"parsed": record.metadata, "index": result}, ensure_ascii=False, indent=2))

    elif args.command == "stats":
        print(json.dumps({"records": indexer.count()}, indent=2))


if __name__ == "__main__":
    main()
